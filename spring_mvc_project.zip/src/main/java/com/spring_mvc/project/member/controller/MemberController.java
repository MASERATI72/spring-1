package com.spring_mvc.project.member.controller;

import java.security.Principal;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MemberController {
	//회원가입 폼으로 이동
	@RequestMapping(value="/member/join")
	public String viewUserLoginForm() {		
		return "jsp/member/join"; //로그인 폼으로 이동
	}
	
	
}

